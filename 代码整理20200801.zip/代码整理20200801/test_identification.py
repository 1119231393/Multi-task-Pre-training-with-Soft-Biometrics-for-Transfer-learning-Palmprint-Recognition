# -*- coding: utf-8 -*-

from skimage import io,transform
import tensorflow as tf
import numpy as np
import glob
import os

w=128
h=128
c=3

# 读取图片
def read_img(path1):
    cate = [path1 + x for x in os.listdir(path1) if os.path.isdir(path1 + x)]
    imgs = []
    labels = []#性别标签，女0男1

    for idx, folder in enumerate(cate):
        print(folder+':',idx)
        for im in glob.glob(folder + '/*.bmp'):
            img = io.imread(im)
            img = transform.resize(img, (w, h))
            imgs.append(img)
            number_label = im[-27:-23]
            if idx == 0:
                if im[-12] == 'L':
                    labels.append((int(number_label)-1)*2)
                elif im[-12] == 'R':
                    labels.append((int(number_label)-1)*2 + 1)

            elif idx == 1:
                # labels.append(int(number_label)+44-1)
                if im[-12] == 'L':
                    labels.append((int(number_label)-1)*2+88)
                elif im[-12] == 'R':
                    labels.append((int(number_label)-1)*2 + 1+88)

    return np.asarray(imgs, np.float32), np.asarray(labels, np.int32)

path = '.\data_half_test_classfication\\'
############################
with tf.Session() as sess:
    # saver = tf.train.import_meta_graph('./model_and_log_identification_half_data/my_CNN_load_weight/model0_load_one_softbio_gender/identification.ckpt.meta')
    # saver.restore(sess,tf.train.latest_checkpoint('./model_and_log_identification_half_data/my_CNN_load_weight/model0_load_one_softbio_gender/'))#0.984
    # saver = tf.train.import_meta_graph('./model_and_log_identification_half_data/my_CNN_load_weight/model0_load_one_softbio_lr/identification.ckpt.meta')
    # saver.restore(sess,tf.train.latest_checkpoint('./model_and_log_identification_half_data/my_CNN_load_weight/model0_load_one_softbio_lr/'))#0.984
    # saver = tf.train.import_meta_graph('./model_and_log_identification_half_data/my_CNN_load_weight/model0_load_two_softbio/identification.ckpt.meta')
    # saver.restore(sess,tf.train.latest_checkpoint('./model_and_log_identification_half_data/my_CNN_load_weight/model0_load_two_softbio/'))#0.984
    # saver = tf.train.import_meta_graph('./model_and_log_identification_half_data/my_CNN_load_weight/model0_load_Tongji/identification.ckpt.meta')
    # saver.restore(sess,tf.train.latest_checkpoint('./model_and_log_identification_half_data/my_CNN_load_weight/model0_load_Tongji/'))#0.984
    saver = tf.train.import_meta_graph('./model_and_log_identification_half_data/my_CNN/model0/identification.ckpt.meta')
    saver.restore(sess,tf.train.latest_checkpoint('./model_and_log_identification_half_data/my_CNN/model0/'))#0.984

    graph = tf.get_default_graph()
    x = graph.get_tensor_by_name("x:0")
    data, label = read_img(path)

    err = 0
    #c测试集3000张
    for i in range(0,60):

        feed_dict = {x: data[i * 50:(i + 1) * 50]}
        logits = graph.get_tensor_by_name("logits_eval:0")

        classification_result = sess.run(logits,feed_dict)

            #打印出预测矩阵
        print(classification_result)
            #打印出预测矩阵每一行最大值的索引
        print(tf.argmax(classification_result,1).eval())
            #根据索引通过字典对应人脸的分类
        output = []
        output = tf.argmax(classification_result,1).eval()
        for j in range(len(output)):
                print("No.",label[i*50+j]+1," is belong to:",output[j]+1)
                if label[i*50+j] !=output[j]:
                    err = err+1
    acc=1-(err/len(data))
    print("acc:",acc)