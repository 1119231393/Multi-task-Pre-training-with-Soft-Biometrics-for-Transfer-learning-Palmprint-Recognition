import cv2 as cv
import tensorflow as tf
import numpy as np
import os
from skimage import io,transform

def grad_cam(prob_name, label, layer_name, sess, feed_dict_data, nb_classes):
    """
    prob_name为softmax输出层节点名, label标签, layer_name最后一层卷积层的节点名, sess,                 
    feed_dict, nb_classes分类数
    """
    graph = tf.get_default_graph()
    conv_output = graph.get_tensor_by_name('layer9-pool5/MaxPool:0')
    prob = graph.get_tensor_by_name('layer11-fc3/MatMul:0')
    loss = tf.multiply(prob, tf.one_hot([label], nb_classes))
    reduced_loss = tf.reduce_sum(loss[0])
    grads = tf.gradients(reduced_loss, conv_output)[0]  # d loss / d conv
    output = sess.run(conv_output, feed_dict=feed_dict_data)
    grads_val = sess.run(grads, feed_dict=feed_dict_data)
    print(output.shape)#(2, 4, 4, 256)
    weights = np.mean(grads_val, axis=(1, 2))  # average pooling
    cams = np.sum(weights * output, axis=3)
    return cams


def save_cam(cam, image, save_path):
    """
    save Grad-CAM images
    """

    cam = cam[0]  # the first GRAD-CAM for the first image in  batch
    # image = np.uint8(image_batch[0][:, :, ::-1] * 255.0) # RGB -> BGR
    cam = cv.resize(cam, (128, 128))  # enlarge heatmap
    # cam = np.maximum(cam, 0)
    cam = cam*-1
    heatmap = 1-cam / np.max(cam)  # normalize
    cam = cv.applyColorMap(np.uint8(255 * heatmap), cv.COLORMAP_JET)
    # balck-and-white to color
    cam = np.float32(cam) + np.float32(image)  # everlay heatmap onto the image
    cam = 255 * cam / np.max(cam)
    cam = np.uint8(cam)

    cv.imwrite(save_path +"cam.jpg", cam)
    cv.imwrite(save_path +"heatmap.jpg", (heatmap * 255.0).astype(np.uint8))
    cv.imwrite(save_path +"segmentation.jpg", (heatmap[:, :, None].astype(float) * image).astype(np.uint8))

    return cam


def main():
    IMAGE_PATH = './data_all_RGB/All_Female_Multi_RGB/0001_Multi_RGB_L_1_01_s.bmp'
    # IMAGE_PATH = './data_all_RGB/All_Male_Multi_RGB/0001_Multi_RGB_R_1_01_s.bmp'
    output_node_names = "layer11-fc3"
    final_conv_name = "layer9-conv5"


    # ckpt = tf.train.get_checkpoint_state(model_path)  # 通过检查点文件锁定最新的模型
    # saver = tf.train.import_meta_graph('./model_and_log_two_and_one_softbio_half_data/model_my_CNN_one_softbio_gender_classfication/gender.ckpt.meta')  # 载入图结构，保存在.meta文件中

    with tf.Session() as sess:
        #性别
        # saver = tf.train.import_meta_graph('./model_and_log_two_and_one_softbio_half_data/model_my_CNN_one_softbio_gender_classfication/gender.ckpt.meta')
        # print([n.name for n in tf.get_default_graph().as_graph_def().node])
        # saver.restore(sess,tf.train.latest_checkpoint('./model_and_log_two_and_one_softbio_half_data/model_my_CNN_one_softbio_gender_classfication/'))
        # 左右手
        # saver = tf.train.import_meta_graph('./model_and_log_two_and_one_softbio_half_data/model_my_CNN_one_softbio_lr_classfication/lr.ckpt.meta')
        # print([n.name for n in tf.get_default_graph().as_graph_def().node])
        # saver.restore(sess,tf.train.latest_checkpoint('./model_and_log_two_and_one_softbio_half_data/model_my_CNN_one_softbio_lr_classfication/'))
        # 无预训练识别
        # saver = tf.train.import_meta_graph('./model_and_log_identification_half_data/my_CNN/model0/identification.ckpt.meta')
        # print([n.name for n in tf.get_default_graph().as_graph_def().node])
        # saver.restore(sess,tf.train.latest_checkpoint('./model_and_log_identification_half_data/my_CNN/model0/'))
        # 单软生物特征预训练识别
        # saver = tf.train.import_meta_graph('./model_and_log_identification_half_data/my_CNN_load_weight/model0_load_one_softbio_lr/identification.ckpt.meta')
        # print([n.name for n in tf.get_default_graph().as_graph_def().node])
        # saver.restore(sess,tf.train.latest_checkpoint('./model_and_log_identification_half_data/my_CNN_load_weight/model0_load_one_softbio_lr/'))
        # 多任务软生物特征预训练识别
        # saver = tf.train.import_meta_graph(
        #     './model_and_log_identification_half_data/my_CNN_load_weight/model0_load_two_softbio/identification.ckpt.meta')
        # print([n.name for n in tf.get_default_graph().as_graph_def().node])
        # saver.restore(sess, tf.train.latest_checkpoint(
        #     './model_and_log_identification_half_data/my_CNN_load_weight/model0_load_two_softbio/'))
        # 同济库预训练识别
        # saver = tf.train.import_meta_graph(
        #     './model_and_log_identification_half_data/my_CNN_load_weight/model0_load_Tongji/identification.ckpt.meta')
        # print([n.name for n in tf.get_default_graph().as_graph_def().node])
        # saver.restore(sess, tf.train.latest_checkpoint(
        #     './model_and_log_identification_half_data/my_CNN_load_weight/model0_load_Tongji/'))
        # 自然图像预训练识别
        saver = tf.train.import_meta_graph(
            './model_and_log_identification_half_data/my_CNN_load_weight/model0_load_CIFAR10/identification.ckpt.meta')
        print([n.name for n in tf.get_default_graph().as_graph_def().node])
        saver.restore(sess, tf.train.latest_checkpoint(
            './model_and_log_identification_half_data/my_CNN_load_weight/model0_load_CIFAR10/'))


        imgs = []
        img = io.imread(IMAGE_PATH)
        img = transform.resize(img, (128, 128))
        # imgs.append(img)
        imgs.append(img)
        input_image_tensor_m = sess.graph.get_tensor_by_name("x:0")


        cam = grad_cam(prob_name=output_node_names, label=0, layer_name=final_conv_name, sess=sess,
                       feed_dict_data={input_image_tensor_m: np.asarray(imgs, np.float32)},
                       nb_classes=500)

        dst_m = save_cam(cam, img, 'identification')
        cv.imshow('dst_m_v', dst_m)
        cv.waitKey(0)

        # print(cam)


if __name__ == '__main__':
    main()