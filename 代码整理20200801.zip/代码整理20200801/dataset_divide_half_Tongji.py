import os, random, shutil
#左右手不同个体，一般训练一般测试
def moveFile(fileDir,tarDir_train,tarDir_test):
        namelist = os.listdir(fileDir)    #取图片的原始路径
        filenumber=len(namelist)
        for i in range(0,filenumber):
            if namelist[i][-5]>='1' and namelist[i][-5]<='5':
                shutil.copy(fileDir+namelist[i], tarDir_train+namelist[i])
            else:
                shutil.copy(fileDir + namelist[i], tarDir_test + namelist[i])
        return

fileDir = r"D:\MatlabR2016a\workspace\gender_palm_judge\Sort_Paml_ROI_Gender_Database\Gender\Tongji_Contactless_Palmprint_Dataset\\"    #源图片文件夹路径
tarDir_train = r".\Tongji_train_half\\"    #移动到新的文件夹路径
tarDir_test = r".\Tongji_test_half\\"    #移动到新的文件夹路径



moveFile(fileDir,tarDir_train,tarDir_test)

