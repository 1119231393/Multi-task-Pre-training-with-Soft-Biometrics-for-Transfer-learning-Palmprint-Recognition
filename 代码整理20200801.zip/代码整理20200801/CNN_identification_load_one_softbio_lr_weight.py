from skimage import io, transform
import glob
import os
import tensorflow as tf
import numpy as np
import time
import tensorflow.contrib.slim as slim
import cv2
# https://www.jianshu.com/p/6680b5f19e26
#掌纹性别分类，总数据量6000，训练集：测试集=4800：1200=4：1   （female+male）846+3955:210+989
# 44:206
#从所有图像中随机选取
# 训练集路径
path = '.\data_half_train_classfication\\'
# 测试集路径
path2 = '.\data_half_test_classfication\\'

loss_yuzhi = '0'
# 保存模型路径
model_path=r'.\model_and_log_identification_half_data\my_CNN_load_weight\\model'+loss_yuzhi+'_load_one_softbio_lr\identification.ckpt'
kernel_initializer_method = tf.truncated_normal_initializer(stddev=0.1,seed=1)
# 将所有的图片resize成w*h
w = 128
h = 128
c = 3


# 读取图片
def read_img(path1):
    cate = [path1 + x for x in os.listdir(path1) if os.path.isdir(path1 + x)]
    imgs = []
    labels = []#性别标签，女0男1

    for idx, folder in enumerate(cate):
        print(folder+':',idx)
        for im in glob.glob(folder + '/*.bmp'):
            img = io.imread(im)
            img = transform.resize(img, (w, h))
            imgs.append(img)
            number_label = im[-27:-23]
            if idx == 0:
                if im[-12] == 'L':
                    labels.append((int(number_label)-1)*2)
                elif im[-12] == 'R':
                    labels.append((int(number_label)-1)*2 + 1)

            elif idx == 1:
                # labels.append(int(number_label)+44-1)
                if im[-12] == 'L':
                    labels.append((int(number_label)-1)*2+88)
                elif im[-12] == 'R':
                    labels.append((int(number_label)-1)*2 + 1+88)

    return np.asarray(imgs, np.float32), np.asarray(labels, np.int32)

data, label = read_img(path)
data2,label2 = read_img(path2)

# 打乱顺序
num_example = data.shape[0]
arr = np.arange(num_example)
np.random.shuffle(arr)
data = data[arr]
label = label[arr]
num_example2 = data2.shape[0]
arr2 = np.arange(num_example2)
np.random.shuffle(arr2)
data2 = data2[arr2]
label2 = label2[arr2]

x_train = data
y_train = label
x_val = data2
y_val = label2


# -----------------构建网络----------------------
# 占位符
x = tf.placeholder(tf.float32, shape=[None, w, h, c], name='x')
y_ = tf.placeholder(tf.int32, shape=[None, ], name='y_')
def inference(input_tensor, train, regularizer):
    with tf.variable_scope('layer1-conv1'):
        conv1_weights = tf.get_variable("weight",[5,5,3,32],initializer=kernel_initializer_method)
        conv1_biases = tf.get_variable("bias", [32], initializer=tf.constant_initializer(0.0))
        conv1 = tf.nn.conv2d(input_tensor, conv1_weights, strides=[1, 1, 1, 1], padding='SAME')
        relu1 = tf.nn.relu(tf.nn.bias_add(conv1, conv1_biases))

    with tf.name_scope("layer2-pool1"):
        pool1 = tf.nn.max_pool(relu1, ksize = [1,2,2,1],strides=[1,2,2,1],padding="VALID")

    with tf.variable_scope("layer3-conv2"):
        conv2_weights = tf.get_variable("weight",[5,5,32,64],initializer=kernel_initializer_method)
        conv2_biases = tf.get_variable("bias", [64], initializer=tf.constant_initializer(0.0))
        conv2 = tf.nn.conv2d(pool1, conv2_weights, strides=[1, 1, 1, 1], padding='SAME')
        relu2 = tf.nn.relu(tf.nn.bias_add(conv2, conv2_biases))

    with tf.name_scope("layer4-pool2"):
        pool2 = tf.nn.max_pool(relu2, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='VALID')

    with tf.variable_scope("layer5-conv3"):
        conv3_weights = tf.get_variable("weight",[3,3,64,128],initializer=kernel_initializer_method)
        conv3_biases = tf.get_variable("bias", [128], initializer=tf.constant_initializer(0.0))
        conv3 = tf.nn.conv2d(pool2, conv3_weights, strides=[1, 1, 1, 1], padding='SAME')
        relu3 = tf.nn.relu(tf.nn.bias_add(conv3, conv3_biases))

    with tf.name_scope("layer6-pool3"):
        pool3 = tf.nn.max_pool(relu3, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='VALID')

    with tf.variable_scope("layer7-conv4"):
        conv4_weights = tf.get_variable("weight",[3,3,128,128],initializer=kernel_initializer_method)
        conv4_biases = tf.get_variable("bias", [128], initializer=tf.constant_initializer(0.0))
        conv4 = tf.nn.conv2d(pool3, conv4_weights, strides=[1, 1, 1, 1], padding='SAME')
        relu4 = tf.nn.relu(tf.nn.bias_add(conv4, conv4_biases))

    with tf.name_scope("layer8-pool4"):
        pool4 = tf.nn.max_pool(relu4, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='VALID')
        nodes = 6*6*128
        reshaped = tf.reshape(pool4,[-1,nodes])

    #再加一层卷积
    with tf.variable_scope("layer9-conv5"):
        conv5_weights = tf.get_variable("weight",[3,3,128,256],initializer=kernel_initializer_method)
        conv5_biases = tf.get_variable("bias", [256], initializer=tf.constant_initializer(0.0))
        conv5 = tf.nn.conv2d(pool4, conv5_weights, strides=[1, 1, 1, 1], padding='SAME')
        relu5 = tf.nn.relu(tf.nn.bias_add(conv5, conv5_biases))

    with tf.name_scope("layer9-pool5"):
        pool5 = tf.nn.max_pool(relu5, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='VALID')
        nodes = int(np.prod(pool5.get_shape()[1:]))
        reshaped = tf.reshape(pool5,[-1,nodes])
    ###

    with tf.variable_scope('layer9-fc1'):
        fc1_weights = tf.get_variable("weight", [nodes, 4096],
                                      initializer=kernel_initializer_method)
        if regularizer != None: tf.add_to_collection('losses', regularizer(fc1_weights))
        fc1_biases = tf.get_variable("bias", [4096], initializer=tf.constant_initializer(0.1))

        fc1 = tf.nn.relu(tf.matmul(reshaped, fc1_weights) + fc1_biases)
        if train: fc1 = tf.nn.dropout(fc1, 0.5)

    with tf.variable_scope('layer10-fc2'):
        fc2_weights = tf.get_variable("weight", [4096, 4096],
                                      initializer=kernel_initializer_method)
        if regularizer != None: tf.add_to_collection('losses', regularizer(fc2_weights))
        fc2_biases = tf.get_variable("bias", [4096], initializer=tf.constant_initializer(0.1))

        fc2 = tf.nn.relu(tf.matmul(fc1, fc2_weights) + fc2_biases)

        if train: fc2 = tf.nn.dropout(fc2, 0.5)

    with tf.variable_scope('layer11-fc3'):
        fc3_weights = tf.get_variable("weight", [4096, 500],
                                      initializer=kernel_initializer_method)
        if regularizer != None: tf.add_to_collection('losses', regularizer(fc3_weights))
        fc3_biases = tf.get_variable("bias", [500], initializer=tf.constant_initializer(0.1))
        logit = tf.matmul(fc2, fc3_weights) + fc3_biases
    # with tf.variable_scope('layer9-fc1'):
    #     fc1_weights = tf.get_variable("weight", [nodes, 1024],
    #                                   initializer=kernel_initializer_method)
    #     if regularizer != None: tf.add_to_collection('losses', regularizer(fc1_weights))
    #     fc1_biases = tf.get_variable("bias", [1024], initializer=tf.constant_initializer(0.1))
    #
    #     fc1 = tf.nn.relu(tf.matmul(reshaped, fc1_weights) + fc1_biases)
    #     if train: fc1 = tf.nn.dropout(fc1, 0.5)
    #
    # with tf.variable_scope('layer10-fc2'):
    #     fc2_weights = tf.get_variable("weight", [1024, 512],
    #                                   initializer=kernel_initializer_method)
    #     if regularizer != None: tf.add_to_collection('losses', regularizer(fc2_weights))
    #     fc2_biases = tf.get_variable("bias", [512], initializer=tf.constant_initializer(0.1))
    #
    #     fc2 = tf.nn.relu(tf.matmul(fc1, fc2_weights) + fc2_biases)
    #
    #     if train: fc2 = tf.nn.dropout(fc2, 0.5)
    #
    # with tf.variable_scope('layer11-fc3'):
    #     fc3_weights = tf.get_variable("weight", [512, 250],
    #                                   initializer=kernel_initializer_method)
    #     if regularizer != None: tf.add_to_collection('losses', regularizer(fc3_weights))
    #     fc3_biases = tf.get_variable("bias", [250], initializer=tf.constant_initializer(0.1))
    #     logit = tf.matmul(fc2, fc3_weights) + fc3_biases

    return logit,fc2,fc1
# ---------------------------网络结束---------------------------
regularizer = tf.contrib.layers.l2_regularizer(0.0001)
logits, feature_fc2, feature_fc1= inference(x,False,regularizer)
#(小处理)将logits乘以1赋值给logits_eval，定义name，方便在后续调用模型时通过tensor名字调用输出tensor
b = tf.constant(value=1,dtype=tf.float32)
logits_eval = tf.multiply(logits,b,name='logits_eval')
feature_fc2_eval = tf.multiply(feature_fc2,b,name='feature_fc2_eval')
feature_fc1_eval = tf.multiply(feature_fc1,b,name='feature_fc1_eval')
# prediction = tf.nn.softmax(logits, name='prediction')


with tf.name_scope('trainloss') as scope:
    loss = tf.losses.sparse_softmax_cross_entropy(labels=y_, logits=logits)
    loss1 = tf.summary.scalar('trainloss_gender', loss)

    loss_total = loss

with tf.name_scope('testloss') as scope:
    loss2 = tf.losses.sparse_softmax_cross_entropy(labels=y_, logits=logits)
    loss2 = tf.summary.scalar('testloss_gender', loss2)


# 类似梯度下降,用Adam优化算法求loss最小值
#train_op = tf.train.AdamOptimizer(learning_rate=0.001).minimize(loss)
train_op = tf.train.AdamOptimizer(learning_rate=0.0001).minimize(loss_total)
# 判断logits中最大概率的预测与y是否相等,返回logits的最大下标，即预测结果，返回矩阵
correct_prediction = tf.equal(tf.cast(tf.argmax(logits, 1), tf.int32), y_)

with tf.name_scope('trainacc') as scope:
    # true为1，false为0，计算平均值，作为准确率
    acc = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
    acc1 = tf.summary.scalar('trainacc_gender', acc)

with tf.name_scope('testacc') as scope:
    acc2 = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
    acc2 = tf.summary.scalar('testacc_gender', acc2)

# 定义一个函数，按批次取数据，一次取batch_size个数据
def minibatches(inputs=None, targets=None, batch_size=None, shuffle=False):
    assert len(inputs) == len(targets)

    if shuffle:
        indices = np.arange(len(inputs))
        np.random.shuffle(indices)
    for start_idx in range(0, len(inputs) - batch_size + 1, batch_size):
        if shuffle:
            excerpt = indices[start_idx:start_idx + batch_size]
        else:
            excerpt = slice(start_idx, start_idx + batch_size)
        yield inputs[excerpt], targets[excerpt]


# 训练和测试数据，可将n_epoch设置更大一些
saver=tf.train.Saver()
n_epoch = 400
batch_size = 128  # 越小对显卡要求越低，过拟合的话增大batch_size
gpu_options = tf.GPUOptions(per_process_gpu_memory_fraction=0.8)
sess = tf.Session(config=tf.ConfigProto(gpu_options=gpu_options, log_device_placement=True))
sess.run(tf.global_variables_initializer())


# exclude = [ 'layer9-fc1', 'layer10-fc2','layer11-fc3','layer11-fc3_1','layer11-fc3_2']
exclude = [ 'layer11-fc3','layer11-fc3_1','layer11-fc3_2']

variables_to_restore = slim.get_variables_to_restore(exclude=exclude)
saver = tf.train.Saver(variables_to_restore)
saver.restore(sess, '.\model_and_log_two_and_one_softbio_half_data\model_my_CNN_one_softbio_lr_classfication\\lr.ckpt')


writer = tf.summary.FileWriter(r'.\model_and_log_identification_half_data\my_CNN_load_weight\\log'+loss_yuzhi+'_load_one_softbio_lr', sess.graph) # 日志文件
i = 1
for epoch in range(n_epoch):
    start_time = time.time()

    print("====epoch %d=====" % epoch)
    # training
    train_loss, train_acc, n_batch = 0, 0, 0

    for x_train_a, y_train_a in minibatches(x_train, y_train, batch_size, shuffle=True):
        # _, err, ac = sess.run([train_op, loss, acc], feed_dict={x: x_train_a, y_: y_train_a, y_lr_: y})
        _, err, ac = sess.run([train_op, loss, acc], feed_dict={x: x_train_a, y_: y_train_a})
        train_loss += err;
        train_acc += ac;

        n_batch += 1

    # writer.add_summary(train_loss, epoch)
    # writer.add_summary(train_acc, epoch)

    result = sess.run(loss1, feed_dict={x: x_train_a, y_: y_train_a})
    result1 = sess.run(acc1, feed_dict={x: x_train_a, y_: y_train_a})
    writer.add_summary(result, epoch)
    writer.add_summary(result1, epoch)

    print("   identification train loss: %f" % (np.sum(train_loss)/ n_batch))
    print("   identification train acc: %f" % (np.sum(train_acc)/ n_batch))



    # validation
    val_loss, val_acc, n_batch = 0, 0, 0
    for x_val_a, y_val_a in minibatches(x_val, y_val, batch_size, shuffle=True):
        err, ac = sess.run([loss, acc], feed_dict={x: x_val_a, y_: y_val_a})
        val_loss += err;
        val_acc += ac;
        n_batch += 1

    result2 = sess.run(loss2, feed_dict={x: x_val_a, y_: y_val_a})
    result3 = sess.run(acc2, feed_dict={x: x_val_a, y_: y_val_a})
    writer.add_summary(result2, epoch)
    writer.add_summary(result3, epoch)
    print("   identification_val loss: %f" % (np.sum(val_loss) / n_batch))
    print("   identification_val acc: %f" % (np.sum(val_acc) / n_batch))

    i = i + 1
saver = tf.train.Saver()
saver.save(sess,model_path)
sess.close()