
from PIL import Image
from skimage import io, transform
import glob
import os
import tensorflow as tf
import numpy as np
import time
import tensorflow.contrib.slim as slim
# 读取图片
w=128
h=128
def mirro(path1):
    cate = [path1 + x for x in os.listdir(path1) if os.path.isdir(path1 + x)]

    for idx, folder in enumerate(cate):
        print(folder+':',idx)
        list = os.listdir(folder)
        iii = 0
        for im in glob.glob(folder + '/*.bmp'):
            pri_image = Image.open(im)
            pri_image.transpose(Image.FLIP_LEFT_RIGHT).save(folder+'/mirro_'+list[iii])
            iii=iii+1

    return

mirro("data_anren_gender_with_mirro/train/")
mirro("data_anren_gender_with_mirro/test/")
mirro("data_anren_gender_with_mirro/valid/")


