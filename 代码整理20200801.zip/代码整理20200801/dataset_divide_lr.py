import os, random, shutil
def moveFile(fileDir,tarDir_train, tarDir_test):
        pathDir = os.listdir(fileDir)    #取图片的原始路径
        filenumber=len(pathDir)
        rate=1/5    #自定义抽取图片的比例，比方说100张抽10张，那就是0.1
        picknumber=int(filenumber*rate) #按照rate比例从文件夹中取一定数量图片
        sample = random.sample(pathDir, picknumber)  #随机选取picknumber数量的样本图片
        print (sample)
        for name in sample:
            shutil.copy(fileDir + name, tarDir_test + name)
        for name in pathDir:
            if name not in sample:
                shutil.copy(fileDir+name, tarDir_train+name)
        return

fileDir = r"data_all_RGB/All_Female_Multi_RGB/"    #源图片文件夹路径
tarDir_train = r"data_traintest41_train_lr//0_All_Female_Multi_RGB/"    #移动到新的文件夹路径
tarDir_test = r"data_traintest41_test_lr//0_All_Female_Multi_RGB/"    #移动到新的文件夹路径
fileDir2 = r"data_all_RGB/All_Male_Multi_RGB/"  # 源图片文件夹路径
tarDir2_train = r"data_traintest41_train_lr/1_All_Male_Multi_RGB/"    #移动到新的文件夹路径
tarDir2_test = r"data_traintest41_test_lr/1_All_Male_Multi_RGB/"  # 移动到新的文件夹路径

moveFile(fileDir,tarDir_train,tarDir_test)
moveFile(fileDir2,tarDir2_train,tarDir2_test)
