# -*- coding: utf-8 -*-

from skimage import io,transform
import tensorflow as tf
import numpy as np
import glob
import os

w=128
h=128
c=3
imList=list()
# 读取图片
def read_img(path1):
    cate = [path1 + x for x in os.listdir(path1) if os.path.isdir(path1 + x)]
    imgs = []
    labels = []#性别标签，女0男1
    labels_lr = []#左右手标签,左0右1

    for idx, folder in enumerate(cate):
        print(folder+':',idx)
        for im in glob.glob(folder + '/*.bmp'):
            #im=im.replace('\\','/')
            #print('reading the images:%s' % (im))
            imList.append(im)
            img = io.imread(im)
            img = transform.resize(img, (w, h))
            imgs.append(img)
            labels.append(idx)
            if "_L_" in im:
                labels_lr.append(0)
            elif "_R_" in im:
                labels_lr.append(1)
    return np.asarray(imgs, np.float32), np.asarray(labels, np.int32), np.asarray(labels_lr, np.int32)

# path = '.\data_half_test_classfication\\'
path = '.\data_anren_gender_with_mirro\\test\\'
############################
with tf.Session() as sess:
    # saver = tf.train.import_meta_graph('./model_and_log_two_and_one_softbio_half_data/model_my_CNN_one_softbio_gender_classfication/gender.ckpt.meta')
    # saver.restore(sess,tf.train.latest_checkpoint('./model_and_log_two_and_one_softbio_half_data/model_my_CNN_one_softbio_gender_classfication/'))
    # saver = tf.train.import_meta_graph('./model_and_log_two_and_one_softbio_half_data/model_my_CNN_one_softbio_lr_classfication_epoch400_traintest_31/lr.ckpt.meta')
    # saver.restore(sess,tf.train.latest_checkpoint('./model_and_log_two_and_one_softbio_half_data/model_my_CNN_one_softbio_lr_classfication_epoch400_traintest_31/'))
    # saver = tf.train.import_meta_graph('./model_and_log_two_and_one_softbio_half_data/model_my_CNN_two_softbio_classfication/two_softbio.ckpt.meta')
    # saver.restore(sess,tf.train.latest_checkpoint('./model_and_log_two_and_one_softbio_half_data/model_my_CNN_two_softbio_classfication/'))
    # saver = tf.train.import_meta_graph('./model_and_log_two_and_one_softbio_half_data_epoch1000\model_my_CNN_one_softbio_gender_classfication/gender.ckpt.meta')
    # saver.restore(sess,tf.train.latest_checkpoint('./model_and_log_two_and_one_softbio_half_data_epoch1000\model_my_CNN_one_softbio_gender_classfication/'))
    # saver = tf.train.import_meta_graph('./model_and_log_two_and_one_softbio_half_data/model_my_CNN_two_softbio_classfication_epoch1000/two_softbio.ckpt.meta')
    # saver.restore(sess,tf.train.latest_checkpoint('./model_and_log_two_and_one_softbio_half_data/model_my_CNN_two_softbio_classfication_epoch1000/'))
    saver = tf.train.import_meta_graph('./model_and_log_two_and_one_softbio_half_data/model_my_CNN_one_softbio_gender_classfication_epoch400_anren_with_mirro/gender.ckpt.meta')
    saver.restore(sess,tf.train.latest_checkpoint('./model_and_log_two_and_one_softbio_half_data/model_my_CNN_one_softbio_gender_classfication_epoch400_anren_with_mirro/'))


    graph = tf.get_default_graph()
    x = graph.get_tensor_by_name("x:0")
    data, label, label_lr = read_img(path)
    label_lr=label
    mistake = list()
    # err = 0
    err_lr = 0
    #c测试集3000张
    for i in range(0,60):
        if (i + 1) * 50 < len(data):
            feed_dict = {x: data[i * 50:(i + 1) * 50]}
        else:
            feed_dict = {x: data[i * 50:len(data)]}
        logits = graph.get_tensor_by_name("logits_eval:0")
        # conv_output = graph.get_tensor_by_name('layer9-pool5/pool5:0')
        prob = graph.get_tensor_by_name('layer11-fc3:0')

        # logits_lr = graph.get_tensor_by_name("logits_lr_eval:0")
        # classification_result = sess.run(logits,feed_dict)
        classification_result_lr = sess.run(logits,feed_dict)
            #打印出预测矩阵
        # print(classification_result)
            #打印出预测矩阵每一行最大值的索引
        # print(tf.argmax(classification_result,1).eval())
            #根据索引通过字典对应人脸的分类
        # output = []
        # output = tf.argmax(classification_result,1).eval()
        output_lr = []
        output_lr = tf.argmax(classification_result_lr,1).eval()
        for j in range(len(output_lr)):
                # print("No.",label[i*50+j]+1," is belong to:",output[j]+1)
                # if label[i*50+j] !=output[j]:
                #     err = err+1
                if label_lr[i*50+j] !=output_lr[j]:
                    err_lr = err_lr+1
                    mistake.append(imList[i*50+j])
        if (i + 1) * 50 > len(data):
            break
    # acc=1-(err/len(data))
    acc_lr = 1 - (err_lr / len(data))
    # print("acc:",acc)
    print("acc_lr:", acc_lr)
    print("mistake_size:", len(mistake))
    print("mistake:", mistake)